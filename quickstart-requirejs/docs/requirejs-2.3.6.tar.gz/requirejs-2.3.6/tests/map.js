define("map",
  function() {
    return {
      name: "map"
    };
  }
);
