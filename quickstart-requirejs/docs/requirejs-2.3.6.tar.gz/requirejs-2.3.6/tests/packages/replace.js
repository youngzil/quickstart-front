//Tests overriding a package path with a more specific mapping.
define({
    name: 'fake/alpha/replace'
});
