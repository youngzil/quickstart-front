define({
    name: 'dojox/window/pane'
});
