define({
    name: 'b'
});
