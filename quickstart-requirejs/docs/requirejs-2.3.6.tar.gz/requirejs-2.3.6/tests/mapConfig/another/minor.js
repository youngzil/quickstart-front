define({
    name: 'another/minor'
});

