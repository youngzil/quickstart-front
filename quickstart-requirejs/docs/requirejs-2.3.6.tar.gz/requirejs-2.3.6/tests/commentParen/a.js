define(function (require) {
    var b = require ('b')// a comment right against the require

    return {
        name: 'a',
        b: b
    };
});
