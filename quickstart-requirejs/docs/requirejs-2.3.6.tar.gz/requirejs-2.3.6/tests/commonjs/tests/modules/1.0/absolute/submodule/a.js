define(["require", "exports", "module", "b"], function(require, exports, module) {
exports.foo = function () {
    return require('b');
};

});
