define({
  name: 'b'
});
