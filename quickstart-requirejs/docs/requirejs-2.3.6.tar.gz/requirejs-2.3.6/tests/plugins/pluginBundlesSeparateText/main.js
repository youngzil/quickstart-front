define('text!template.html', [], function () {
    return 'main template';
});
