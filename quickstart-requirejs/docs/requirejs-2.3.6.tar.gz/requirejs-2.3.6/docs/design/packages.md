# Packages

Moved to [pkg project](https://github.com/requirejs/pkg/blob/master/docs/design/packages.md)
