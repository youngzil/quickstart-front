#!/usr/bin/env node
console.log('ok')
